# Casos d'ús

Els casos d'ús representen la lògica de negoci; què és el que pot fer l'aplicació.

Pràcticament, podria tractar-se de la implementació directa dels casos d'ús definits a un diagrama UML.

Tenim una explicació dels casos d'ús en Dart a: https://medium.com/@ahmedhosni803/why-and-when-to-use-use-cases-in-flutter-clean-architecture-438e796be1d6

En aquest cas, els casos d'ús seran:

* Obtenir la llista d'entrants: get_entrants_use_case.dart
* Obtenir la llista de plats principals: get_principals_use_case.dart
* Obtenir la llista de begudes: get_begudes_use_case.dart


