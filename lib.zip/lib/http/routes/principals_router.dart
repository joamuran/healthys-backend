import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';
import '../controllers/principals_controller.dart';

Router buildPrincipalsRoutes(
  PrincipalsController controller,
) {
  final r = Router()
    ..get(
      '/', // Davant la petició GET, fem ús del mètode getPrincipals del controlador PrincipalsController
      (Request request) => controller
          .getPrincipals(request),
    )
    ..get(
      '/<tipus>',
      controller.getPrincipalsPerTipus,
    );

  return r;
}
